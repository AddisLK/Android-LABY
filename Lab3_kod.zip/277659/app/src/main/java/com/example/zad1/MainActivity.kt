package com.example.zad1

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.zad1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // ZAWSZE najpierw super
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {
            // Pobierz tekst z EditText
            val inputText = binding.editTextText.text.toString()

            // a) Wypisz do Logcat
            Log.d("MainActivity", "Wpisano: $inputText")

            // b) Ustaw tekst w TextView
            binding.textView2.text = "Podane imię i nazwisko to: $inputText"

            // c) Pokaż Toast
            Toast.makeText(applicationContext, inputText, Toast.LENGTH_SHORT).show()
        }
    }
}
