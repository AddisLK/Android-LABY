package com.example.zad1_bmi

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import android.widget.ImageView
import android.widget.LinearLayout
import android.util.Log
import android.widget.Toast


class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Sprawdzenie preferencji motywu
        val prefs = getSharedPreferences("theme_prefs", MODE_PRIVATE)
        val isDarkTheme = prefs.getBoolean("dark_theme", false)

        // Ustawienie
        if (isDarkTheme) {
            setTheme(R.style.AppTheme_Dark)
        } else {
            setTheme(R.style.AppTheme_Light)
        }

        super.onCreate(savedInstanceState)

        // Tworzenie Splash Screenu programowo
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#A2E4B8")) // kolor splash
            gravity = android.view.Gravity.CENTER
        }

        setContentView(layout)

        // Opóźnienie
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, 2000)
        showLifecycleMessage("onCreate")

    }

    private val TAG = "SplashActivity"

    override fun onStart() {
        super.onStart()
        showLifecycleMessage("onStart")
    }

    override fun onResume() {
        super.onResume()
        showLifecycleMessage("onResume")
    }

    override fun onPause() {
        super.onPause()
        showLifecycleMessage("onPause")
    }

    override fun onStop() {
        super.onStop()
        showLifecycleMessage("onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        showLifecycleMessage("onDestroy")
    }

    override fun onRestart() {
        super.onRestart()
        showLifecycleMessage("onRestart")
    }

    private fun showLifecycleMessage(method: String) {
        Toast.makeText(this, "$TAG: $method", Toast.LENGTH_SHORT).show()
        Log.d(TAG, method)
    }

}
