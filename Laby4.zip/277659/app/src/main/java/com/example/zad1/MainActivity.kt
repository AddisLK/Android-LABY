package com.example.zad1

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.zad1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.Losuj.setOnClickListener {
            Toast.makeText(this, "Rzuciłeś kostką...", Toast.LENGTH_SHORT).show()

            Handler(Looper.getMainLooper()).postDelayed({
                val wynik = (1..6).random() //generuje liczbe losowa z podanego zakresu

                val aktywnosc = when (wynik) { //wykorzystanie lambdy do osadzonego bloku
                    1 ->  binding.obraz.setImageResource(R.drawable.dice1)
                    2 -> binding.obraz.setImageResource(R.drawable.dice2)
                    3 -> binding.obraz.setImageResource(R.drawable.dice3)
                    4 -> binding.obraz.setImageResource(R.drawable.dice4)
                    5 -> binding.obraz.setImageResource(R.drawable.dice5)
                    6 -> binding.obraz.setImageResource(R.drawable.dice6)
                    else -> "Chillout"
                }

            }, 1500)
        }
    }
}
