package com.example.zad1_bmi
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var weightSlider: Slider
    private lateinit var heightSlider: Slider
    private lateinit var calculateButton: Button
    private lateinit var toggleThemeButton: Switch
    private lateinit var resultText: TextView
    private lateinit var imageView: ImageView
    private var isDarkTheme = false

    override fun onCreate(savedInstanceState: Bundle?) {
        isDarkTheme = isDarkThemeEnabled()
        if (isDarkTheme) {
            setTheme(R.style.AppTheme_Dark)
        } else {
            setTheme(R.style.AppTheme_Light)
        }

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Inicjalizacja widoków
        weightSlider = findViewById(R.id.weightSlider)
        heightSlider = findViewById(R.id.heightSlider)
        calculateButton = findViewById(R.id.calculateButton)
        toggleThemeButton = findViewById(R.id.switchTheme)
        resultText = findViewById(R.id.resultText)
        imageView = findViewById(R.id.imageView)

        // Inicjalizacja etykiet suwaków
        val weightLabel = findViewById<TextView>(R.id.weightLabel)
        val heightLabel = findViewById<TextView>(R.id.heightLabel)

        // Ustawienie początkowych wartości suwaków
        weightLabel.text = "Waga: ${weightSlider.value.toInt()} kg"
        heightLabel.text = "Wzrost: ${heightSlider.value.toInt()} cm"

        // Zmiana etykiety w momencie zmiany wartości suwaka
        weightSlider.addOnChangeListener { _, value, _ ->
            weightLabel.text = "Waga: ${value.toInt()} kg"
        }

        heightSlider.addOnChangeListener { _, value, _ ->
            heightLabel.text = "Wzrost: ${value.toInt()} cm"
        }

        // Ustaw stan przełącznika motywu
        toggleThemeButton.isChecked = isDarkTheme

        calculateButton.setOnClickListener {
            calculateBMI()
        }

        toggleThemeButton.setOnCheckedChangeListener { _, isChecked ->
            isDarkTheme = isChecked
            saveThemePreference(isDarkTheme)
            recreate()
        }
    }

    private fun calculateBMI() {
        val weight = weightSlider.value
        val heightCm = heightSlider.value

        if (weight == 0f || heightCm == 0f) {
            Toast.makeText(this, "Wprowadź wagę i wzrost", Toast.LENGTH_SHORT).show()
            return
        }

        val heightM = heightCm / 100
        val bmi = weight / (heightM * heightM)

        val (category, color) = when {
            bmi < 18.5 -> "Niedowaga" to R.color.colorUnderweight
            bmi < 24.9 -> "Waga prawidłowa" to R.color.colorNormal
            bmi < 29.9 -> "Nadwaga" to R.color.colorOverweight
            else -> "Otyłość" to R.color.colorObese
        }

        resultText.text = "Twoje BMI: %.2f\n$category".format(bmi)
        resultText.setTextColor(resources.getColor(color, theme))
    }

    // Zapis motywu do pamięci
    private fun saveThemePreference(isDark: Boolean) {
        val prefs = getSharedPreferences("theme_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("dark_theme", isDark).apply()
    }

    // Odczyt motywu
    private fun isDarkThemeEnabled(): Boolean {
        val prefs = getSharedPreferences("theme_prefs", MODE_PRIVATE)
        return prefs.getBoolean("dark_theme", false)
    }
}
