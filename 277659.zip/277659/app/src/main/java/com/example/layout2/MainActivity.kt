package com.example.layout2

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private var counter = 0 // Licznik

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textCounter = findViewById<TextView>(R.id.textView2)
        val buttonIncrease = findViewById<Button>(R.id.buttonIncrease)

        buttonIncrease.setOnClickListener {
            counter++
            textCounter.text = counter.toString()
        }
    }
}